
import { useState } from "react";
import axios from "axios";

export default function App() {
  const [step, setStep] = useState("home");
  const [qr, setQr] = useState("");
  const [ref, setRef] = useState("");
  const [phone, setPhone] = useState("");
  const [txid, setTxid] = useState("");
  const [payments, setPayments] = useState([]);
  const [ticketId, setTicketId] = useState("");
  const [result, setResult] = useState("");

  const backend = "http://localhost:5000";

  const buy = async () => {
    const res = await axios.post(`${backend}/generate-payment`, { amount: 50 });
    setQr(res.data.qr);
    setRef(res.data.ref);
    setStep("pay");
  };

  const submit = async () => {
    await axios.post(`${backend}/confirm-payment`, { ref, phone, txid });
    setStep("done");
  };

  const load = async () => {
    const res = await axios.get(`${backend}/payments`);
    setPayments(res.data);
    setStep("admin");
  };

  const approve = async (r) => {
    const res = await axios.post(`${backend}/approve`, { ref: r });
    alert("Ticket created: " + res.data.ticketId);
  };

  const verify = async () => {
    const res = await axios.post(`${backend}/verify`, { ticketId });
    setResult(res.data.valid ? "VALID" : "INVALID");
  };

  return (
    <div style={{ padding: 20 }}>
      {step === "home" && (
        <div>
          <h1>PentTV Tickets</h1>
          <button onClick={buy}>Buy Ticket</button>
          <button onClick={load}>Admin</button>
          <button onClick={() => setStep("scan")}>Scanner</button>
        </div>
      )}

      {step === "pay" && (
        <div>
          <h2>Payment</h2>
          <img src={qr} width="200" />
          <p>{ref}</p>
          <input placeholder="Phone" onChange={e => setPhone(e.target.value)} />
          <input placeholder="TxID" onChange={e => setTxid(e.target.value)} />
          <button onClick={submit}>Submit</button>
        </div>
      )}

      {step === "done" && <h2>Submitted</h2>}

      {step === "admin" && (
        <div>
          <h2>Admin</h2>
          {payments.map(p => (
            <div key={p.ref}>
              {p.ref} - {p.status}
              <button onClick={() => approve(p.ref)}>Approve</button>
            </div>
          ))}
        </div>
      )}

      {step === "scan" && (
        <div>
          <h2>Scanner</h2>
          <input onChange={e => setTicketId(e.target.value)} />
          <button onClick={verify}>Verify</button>
          <h3>{result}</h3>
        </div>
      )}
    </div>
  );
}
