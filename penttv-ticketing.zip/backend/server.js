
import express from "express";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";
import QRCode from "qrcode";

const app = express();
app.use(cors());
app.use(express.json());

let payments = [];
let tickets = [];

// generate payment QR
app.post("/generate-payment", async (req, res) => {
  const ref = "PENT-" + uuidv4().slice(0, 6);
  const amount = req.body.amount;

  const qrData = `MoMo:0551234567|Amount:${amount}|Ref:${ref}`;
  const qr = await QRCode.toDataURL(qrData);

  payments.push({ ref, amount, status: "pending" });

  res.json({ ref, qr });
});

// confirm payment
app.post("/confirm-payment", (req, res) => {
  const { ref, phone, txid } = req.body;

  const payment = payments.find(p => p.ref === ref);
  if (payment) {
    payment.phone = phone;
    payment.txid = txid;
    payment.status = "submitted";
  }

  res.json({ message: "submitted" });
});

// get payments
app.get("/payments", (req, res) => {
  res.json(payments);
});

// approve payment
app.post("/approve", async (req, res) => {
  const { ref } = req.body;

  const ticketId = uuidv4();
  const qr = await QRCode.toDataURL(ticketId);

  tickets.push({ ticketId, ref, used: false, qr });

  res.json({ ticketId });
});

// verify ticket
app.post("/verify", (req, res) => {
  const { ticketId } = req.body;

  const ticket = tickets.find(t => t.ticketId === ticketId);

  if (!ticket) return res.json({ valid: false });

  if (ticket.used) return res.json({ valid: false, message: "Used" });

  ticket.used = true;
  res.json({ valid: true });
});

app.listen(5000, () => console.log("Backend running on 5000"));
